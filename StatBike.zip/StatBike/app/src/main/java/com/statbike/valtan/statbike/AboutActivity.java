package com.statbike.valtan.statbike;


import android.app.Activity;
import android.os.Bundle;

public class AboutActivity extends Activity {

    /*
    @param Bundle saveInstanceState
    create a instance
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_layout);
    }

}
